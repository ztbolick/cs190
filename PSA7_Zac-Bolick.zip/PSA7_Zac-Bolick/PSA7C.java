/**
 * Auto Generated Java Class.
 */
public class PSA7C {
  
  
  public static void main(String[] args) { 
    Sound s2 = new Sound("./resources/sun.wav");
    
    s2.explore();
    Sound s3 = new Sound (s2.soundPalindrome());
    s3.explore();
    
  }
}
